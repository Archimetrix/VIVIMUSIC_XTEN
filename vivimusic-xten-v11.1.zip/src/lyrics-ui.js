/**
 * VIVIMUSIC XTEN — lyrics-ui.js
 */

(() => {
  'use strict';

  const PANEL_ID   = 'vivi-lyrics-panel';
  const INFO_BTN_ID    = 'vivi-lyrics-info-btn';
  const OFFSET_PANEL_ID = 'vivi-lyrics-offset-panel';
  const DEBUG      = false;
  const log        = (...a) => DEBUG && console.log('[Vivi:LyricsUI]', ...a);
  const OFFSET_DB_PFX  = 'vivi_lyrics_offset_';
  const OFFSET_STEP_MS = 100;
  const EXCLUDED_DB_PFX = 'vivi_lyrics_excluded_';
  let isRefetchingLyrics = false;

  let settings = { lyricsEnabled: true, autoSwitchLyrics: true, lyricsShowForVideos: false, dancerOnNotFound: true };
  let currentTrackKey = null;
  let currentResult = null;  
  let isLoadingLyrics = false;
  let rafId = null;
  let lastRenderedKey = '';
  let anchorLineEl = null; // last line that was active; keeps blur distances stable in gaps
  let activeLineEl = null;
  let tabObserver = null;
  let syncRaf = null;
  let contentDirty = false; 

  // Cumulative duration (ms) of SponsorBlock "non-music" segments the player
  // has already auto-skipped through for the current track. Lyrics providers
  // time their lines from the actual start of the song, but when a video
  // opens with a skipped intro/talking segment the video's own currentTime
  // runs ahead of that by exactly this much — so we subtract it back out.
  let sponsorOffsetMs = 0;

  // Manual, user-tuned correction (ms) for cases where a specific provider's
  // timing is itself a little early/late for a given track. Positive values
  // make lyrics advance sooner (subtracted the same way sponsorOffsetMs is).
  let manualOffsetMs = 0;
  // Last value actually persisted to chrome.storage for the current
  // track/provider — compared against manualOffsetMs to know whether the
  // offset panel's Save button has anything unsaved to write.
  let savedOffsetMs = 0;
  // Whether the inline offset editor (opened via the "i" button) is expanded.
  let offsetPanelOpen = false;
  let currentTrack = null; // {song, artist, duration} — for the offset "database" key
  let currentIsVideo = false;
  const VIDEO_BLOCKED = Object.freeze({ videoBlocked: true });

  // Lyrics fonts are loaded through the FontFace API from the content script
  // instead of relying only on the @font-face rules in lyrics-fonts.css.
  // Those rules need the page to allow the extension URL as a font source,
  // which music.youtube.com does not always do — the lyrics then silently
  // fell back to the default font. Fetching the file from the extension and
  // handing the bytes to FontFace avoids the page's CSP entirely.
  const LYRICS_FONT_FILES = {
    playfair:     { family: 'ViviLyr Playfair',      file: 'playfair-display.woff2', weight: '400 900' },
    cormorant:    { family: 'ViviLyr Cormorant',     file: 'cormorant.woff2',        weight: '300 700', sizeAdjust: '118%' },
    dmserif:      { family: 'ViviLyr DM Serif',      file: 'dm-serif-display.woff2', weight: '400' },
    lora:         { family: 'ViviLyr Lora',          file: 'lora.woff2',             weight: '400 700' },
    poppins:      { family: 'ViviLyr Poppins',       file: 'poppins.woff2',          weight: '700' },
    montserrat:   { family: 'ViviLyr Montserrat',    file: 'montserrat.woff2',       weight: '100 900' },
    outfit:       { family: 'ViviLyr Outfit',        file: 'outfit.woff2',           weight: '100 900' },
    spacegrotesk: { family: 'ViviLyr Space Grotesk', file: 'space-grotesk.woff2',    weight: '300 700' },
    caveat:       { family: 'ViviLyr Caveat',        file: 'caveat.woff2',           weight: '400 700', sizeAdjust: '125%' },
    dancing:      { family: 'ViviLyr Dancing',       file: 'dancing-script.woff2',   weight: '400 700', sizeAdjust: '112%' },
    pacifico:     { family: 'ViviLyr Pacifico',      file: 'pacifico.woff2',         weight: '400',     sizeAdjust: '92%' },
    bebas:        { family: 'ViviLyr Bebas',         file: 'bebas-neue.woff2',       weight: '400',     sizeAdjust: '110%' },
  };
  const loadedLyricsFonts = new Set();
  async function ensureLyricsFontLoaded(id) {
    const key = String(id || '').replace(/[^a-z0-9]/gi, '');
    const def = LYRICS_FONT_FILES[key];
    if (!def || loadedLyricsFonts.has(key)) return;
    loadedLyricsFonts.add(key);
    try {
      const res = await fetch(chrome.runtime.getURL('src/fonts/' + def.file));
      const buf = await res.arrayBuffer();
      const desc = { weight: def.weight, display: 'swap' };
      if (def.sizeAdjust) desc.sizeAdjust = def.sizeAdjust;
      const face = new FontFace(def.family, buf, desc);
      await face.load();
      document.fonts.add(face);
      // Re-apply so the line re-lays-out with the freshly loaded face.
      applyLyricsStyleClasses();
    } catch (e) {
      loadedLyricsFonts.delete(key);
      console.debug('[ViviMusic Xten] lyrics font failed to load:', key, e);
    }
  }

  chrome.storage.local.get(
    { lyricsEnabled: true, autoSwitchLyrics: true, lyricsShowForVideos: false, dancerOnNotFound: true, resourceSaverEnabled: false, lyricsAlign: 'center', lyricsAnimationStyle: 'apple', lyricsFont: 'default', lyricsRoman: 'off', lyricsRomanJa: true, lyricsRomanLangs: null },
    (s) => {
      settings = s;
      if (settings.lyricsAnimationStyle === 'fluidglow' || settings.lyricsAnimationStyle === 'spring') settings.lyricsAnimationStyle = 'fluid';
      applyLyricsStyleClasses();
    }
  );

  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type !== 'VIVI_SETTINGS') return;
    if ('lyricsEnabled' in msg) {
      settings.lyricsEnabled = msg.lyricsEnabled;
      if (!settings.lyricsEnabled) teardownPanel();
      else scheduleSync();
    }
    if ('autoSwitchLyrics' in msg) settings.autoSwitchLyrics = msg.autoSwitchLyrics;
    if ('lyricsAlign' in msg) {
      settings.lyricsAlign = msg.lyricsAlign;
      applyLyricsStyleClasses();
    }
    if ('lyricsRoman' in msg || 'lyricsRomanJa' in msg || 'lyricsRomanLangs' in msg) {
      if ('lyricsRoman' in msg) settings.lyricsRoman = msg.lyricsRoman;
      if ('lyricsRomanLangs' in msg) settings.lyricsRomanLangs = msg.lyricsRomanLangs;
      if ('lyricsRomanJa' in msg) settings.lyricsRomanJa = msg.lyricsRomanJa;
      contentDirty = true;
      scheduleSync();
    }
    if ('lyricsFont' in msg) {
      settings.lyricsFont = msg.lyricsFont;
      applyLyricsStyleClasses();
    }
    if ('lyricsAnimationStyle' in msg) {
      settings.lyricsAnimationStyle = msg.lyricsAnimationStyle;
      applyLyricsStyleClasses();
      // Force the active word's fill/glow state to be re-applied under the
      // new animation style rather than waiting for its state to change.
      const active = document.querySelector('.vivi-lyrics-line.vivi-lyrics-active');
      active?.querySelectorAll('.vivi-lyrics-word').forEach((w) => {
        delete w.dataset.fillState;
        w.classList.remove('vivi-lyrics-word-glowing', 'vivi-lyrics-word-bouncing', 'vivi-lyrics-syl-swell');
      });
    }
    if ('dancerOnNotFound' in msg || 'resourceSaverEnabled' in msg) {
      if ('dancerOnNotFound' in msg) settings.dancerOnNotFound = msg.dancerOnNotFound;
      if ('resourceSaverEnabled' in msg) settings.resourceSaverEnabled = msg.resourceSaverEnabled === true;
      // If the panel is currently showing the "no lyrics found" state,
      // re-render it immediately so the toggle takes effect without
      // waiting for the next track.
      if (currentTrack && !isLoadingLyrics && !currentResult) {
        contentDirty = true;
        syncPanelVisibility();
      }
    }
    if ('lyricsShowForVideos' in msg) {
      settings.lyricsShowForVideos = msg.lyricsShowForVideos;
      // Re-evaluate the currently loaded track against the new setting right
      // away, rather than waiting for the next track change.
      if (currentTrack) reevaluateForVideoSetting();
    }
  });

  
  // Resolves a tab by kind ('lyrics', 'comments', ...). Language handling
  // lives in tab-locale.js (setting: Appearance → Language localization).
  function findTabByLabel(label) {
    const tabs = document.querySelectorAll('ytmusic-player-page tp-yt-paper-tab, ytmusic-player-page yt-tab-shape');
    const T = window.__viviTabs;
    for (const tab of tabs) {
      if (T) {
        if (T.kindOf(tab, Array.from(tabs)) === label) return tab;
      } else if ((tab.textContent || '').trim().toLowerCase() === label) {
        return tab;
      }
    }
    return null;
  }

  function isLyricsTabActive() {
    const tab = findTabByLabel('lyrics');
    return !!tab && (tab.getAttribute('aria-selected') === 'true' || tab.hasAttribute('selected'));
  }

  // YT Music renders the Lyrics tab for video tracks too, but ships it
  // disabled (disabled + aria-disabled="true" + pointer-events:none), so
  // it's visible but unclickable and never reachable once the user has
  // navigated to another tab. Since the tab node itself is real, we don't
  // need to build a fake one — just strip the disabling. YTM re-disables
  // it on every tab-strip rebuild (track/route change), so this has to be
  // reasserted continuously rather than run once.
  function enableLyricsTabIfDisabled() {
    const tab = findTabByLabel('lyrics');
    if (!tab) return false;
    if (tab.hasAttribute('disabled') || tab.getAttribute('aria-disabled') === 'true' || tab.style.pointerEvents === 'none') {
      tab.removeAttribute('disabled');
      tab.removeAttribute('aria-disabled');
      tab.style.removeProperty('pointer-events');
      log('re-enabled disabled Lyrics tab');
      return true;
    }
    return false;
  }

  // Retrying variant: polls for the tab briefly. When lyrics don't need a
  // network fetch (video-blocked path), handleTrack() now finishes almost
  // instantly — much faster than YT Music's own tab bar
  // can finish mounting after a track/route change. A single click attempt
  // at that moment can silently miss the "Lyrics" tab element entirely and,
  // unlike the render path, nothing else ever retries the click on its own.
  let lyricsTabRetryId = null;
  function clickLyricsTabWithRetry(attemptsLeft) {
    if (lyricsTabRetryId) { clearTimeout(lyricsTabRetryId); lyricsTabRetryId = null; }
    if (attemptsLeft == null) attemptsLeft = 20; // ~3s at 150ms apart
    const tab = findTabByLabel('lyrics');
    if (tab) {
      enableLyricsTabIfDisabled();
      if (tab.getAttribute('aria-selected') !== 'true' && !tab.hasAttribute('selected')) {
        tab.click();
        log('auto-switched to Lyrics tab (attempt', 21 - attemptsLeft, ')');
      }
      return;
    }
    if (attemptsLeft > 1) {
      lyricsTabRetryId = setTimeout(() => clickLyricsTabWithRetry(attemptsLeft - 1), 150);
    }
  }

  function findTabContentHost() {
    return document.querySelector('ytmusic-player-page #tab-renderer');
  }

  // ── Per-track/per-provider offset "database" (chrome.storage.local) ──
  // Keyed by artist+song+provider so a re-fetch from a different, better-
  // timed provider doesn't inherit a correction that no longer applies.
  function offsetDbKey(track, provider) {
    const raw = `${track.artist}—${track.song}—${provider || 'unknown'}`;
    return OFFSET_DB_PFX + raw.replace(/[^a-z0-9]/gi, '_').slice(0, 110);
  }

  function loadOffset(track, provider) {
    return new Promise((resolve) => {
      const key = offsetDbKey(track, provider);
      chrome.storage.local.get(key, (r) => resolve(r[key]?.offsetMs || 0));
    });
  }

  function saveOffset(track, provider, offsetMs) {
    const key = offsetDbKey(track, provider);
    const entry = {
      song: track.song,
      artist: track.artist,
      duration: track.duration ?? null,
      provider: provider || 'unknown',
      offsetMs,
      updatedAt: Date.now(),
    };
    chrome.storage.local.set({ [key]: entry });
  }

  // ── Per-song "refetched away from this provider" list ──
  // Keyed by artist+song only (no provider in the key, unlike the offset
  // db above) — this is "for this song, don't show provider X again",
  // independent of whichever provider happens to be showing right now.
  // Grows as the user hits "refetch from other providers" repeatedly.
  function excludedDbKey(track) {
    const raw = `${track.artist}—${track.song}`;
    return EXCLUDED_DB_PFX + raw.replace(/[^a-z0-9]/gi, '_').slice(0, 110);
  }

  function loadExcludedProviders(track) {
    return new Promise((resolve) => {
      const key = excludedDbKey(track);
      chrome.storage.local.get(key, (r) => resolve(Array.isArray(r[key]?.keys) ? r[key].keys : []));
    });
  }

  function addExcludedProvider(track, providerKey) {
    if (!providerKey) return;
    const key = excludedDbKey(track);
    chrome.storage.local.get(key, (r) => {
      const keys = new Set(Array.isArray(r[key]?.keys) ? r[key].keys : []);
      keys.add(providerKey);
      chrome.storage.local.set({
        [key]: { song: track.song, artist: track.artist, keys: [...keys], updatedAt: Date.now() },
      });
    });
  }

  function setSponsorOffset(ms) {
    sponsorOffsetMs = Number(ms) || 0;
  }

  function offsetIsDirty() {
    return manualOffsetMs !== savedOffsetMs;
  }

  function updateSaveButtonState() {
    const saveBtn = document.querySelector('#' + OFFSET_PANEL_ID + ' .vivi-offset-save-btn');
    if (!saveBtn) return;
    const dirty = offsetIsDirty();
    saveBtn.textContent = dirty ? 'Save' : 'Saved';
    saveBtn.disabled = !dirty;
    saveBtn.classList.toggle('vivi-offset-save-btn-dirty', dirty);
  }

  function updateOffsetPanelValue() {
    const input = document.querySelector('#' + OFFSET_PANEL_ID + ' .vivi-offset-input');
    if (input && document.activeElement !== input) input.value = manualOffsetMs;
    updateSaveButtonState();
  }

  // Live edits (± buttons / typing) only update in-memory state so the user
  // can preview the new timing against the current playback position; they
  // are NOT written to chrome.storage until the explicit Save button is
  // pressed (see persistManualOffset below).
  function setManualOffsetLive(ms) {
    manualOffsetMs = Number.isFinite(ms) ? ms : 0;
    updateOffsetPanelValue();
  }

  function adjustManualOffset(deltaMs) {
    setManualOffsetLive(manualOffsetMs + deltaMs);
  }

  function persistManualOffset() {
    if (!currentTrack || !currentResult?.provider) return;
    saveOffset(currentTrack, currentResult.provider, manualOffsetMs);
    savedOffsetMs = manualOffsetMs;
    updateSaveButtonState();
  }

  // ── "i" info button beside the Lyrics tab + its inline offset editor ──
  // Pressing "i" no longer opens a floating popup (which could end up
  // anchored to a stale/detached button after navigating to a new song from
  // the homepage). Instead it toggles an editor panel rendered inline at
  // the top of the lyrics list itself, so it's always part of the same
  // panel that gets rebuilt on every track change.
  function toggleOffsetPanel() {
    offsetPanelOpen = !offsetPanelOpen;
    contentDirty = true;
    syncPanelVisibility();
    if (offsetPanelOpen) {
      requestAnimationFrame(() => {
        document.getElementById(OFFSET_PANEL_ID)?.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
      });
    }
  }

  function removeInfoButton() {
    document.getElementById(INFO_BTN_ID)?.remove();
  }

  function ensureInfoButton() {
    const tab = findTabByLabel('lyrics');
    const canShowOffset = settings.lyricsEnabled && !!(currentResult && !currentResult.videoBlocked && currentResult.provider);

    if (!tab || !canShowOffset) {
      removeInfoButton();
      return;
    }

    let wrap = document.getElementById(INFO_BTN_ID);
    if (!wrap || wrap.previousElementSibling !== tab) {
      if (wrap) wrap.remove();

      wrap = document.createElement('span');
      wrap.id = INFO_BTN_ID;
      wrap.className = 'vivi-lyrics-info-wrap';

      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'vivi-lyrics-info-btn';
      btn.textContent = 'i';
      btn.setAttribute('aria-label', 'Lyrics provider & sync options');
      btn.setAttribute('aria-expanded', 'false');
      btn.title = 'Lyrics provider & sync';
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        e.preventDefault();
        toggleOffsetPanel();
      });

      wrap.appendChild(btn);
      tab.insertAdjacentElement('afterend', wrap);
    }

    const btnEl = wrap.querySelector('.vivi-lyrics-info-btn');
    if (btnEl) {
      btnEl.classList.toggle('vivi-lyrics-info-btn-active', offsetPanelOpen);
      btnEl.setAttribute('aria-expanded', offsetPanelOpen ? 'true' : 'false');
    }
  }

  function seekTo(ms) {
    const video = getVideoEl();
    if (!video || Number.isNaN(ms)) return;
    video.currentTime = ms / 1000;
    if (video.paused) video.play().catch(() => {});
  }

  // Only fade an edge when there's actually more content hidden past it —
  // otherwise the very first/last line sits right at the mask's transparent
  // end and looks permanently dimmed even though nothing is scrolled away.
  function updateEdgeFade(host) {
    if (!host || !host.classList.contains('vivi-lyrics-edge-fade')) return;
    const eps = 4;
    const maxScroll = host.scrollHeight - host.clientHeight;
    host.classList.toggle('vivi-fade-top', host.scrollTop > eps);
    host.classList.toggle('vivi-fade-bottom', host.scrollTop < maxScroll - eps);
  }

  function ensurePanel() {
    const host = findTabContentHost();
    if (!host) return null;
    host.classList.add('vivi-lyrics-edge-fade');
    if (!host.dataset.viviFadeBound) {
      host.dataset.viviFadeBound = '1';
      host.addEventListener('scroll', () => updateEdgeFade(host), { passive: true });
      window.addEventListener('resize', () => updateEdgeFade(host));
    }
    updateEdgeFade(host);
    let panel = document.getElementById(PANEL_ID);
    if (panel && panel.parentElement === host) return panel;
    if (panel) panel.remove();

    panel = document.createElement('div');
    panel.id = PANEL_ID;
    host.insertBefore(panel, host.firstChild);
    return panel;
  }

  function hideNativeLyricsContent(host) {
    Array.from(host.children).forEach((child) => {
      if (child.id !== PANEL_ID) child.style.display = 'none';
    });
  }

  // ── Stale native lyrics under Comments / Related ──────────────────────
  // When the user leaves Lyrics for Comments/Related, YT Music keeps the old
  // native lyrics node in #tab-renderer until the new tab's data arrives, and
  // our un-hide on tab click made it visible (plain lyrics under "COMMENTS").
  // We remember each such node together with its text at that moment and keep
  // it hidden only while its text is unchanged. As soon as YTM replaces the
  // node or reuses it for new content, it is shown normally, so nothing the
  // new tab renders can ever stay hidden.
  const staleNative = new Map(); // element -> textContent when marked
  let staleTimer = null;

  function reconcileStale() {
    const host = findTabContentHost();
    for (const [el, text] of Array.from(staleNative)) {
      if (!el.isConnected || !host || el.parentElement !== host) { staleNative.delete(el); continue; }
      if (el.textContent !== text) { staleNative.delete(el); el.style.display = ''; }
    }
    if (!staleNative.size && staleTimer) { clearInterval(staleTimer); staleTimer = null; }
  }

  function markStaleNative(host) {
    staleNative.clear();
    Array.from(host.children).forEach((c) => {
      if (c.id === PANEL_ID) return;
      staleNative.set(c, c.textContent);
      c.style.display = 'none';
    });
    if (staleNative.size && !staleTimer) staleTimer = setInterval(reconcileStale, 150);
  }

  function clearStaleNative(host) {
    staleNative.clear();
    if (staleTimer) { clearInterval(staleTimer); staleTimer = null; }
  }

  function restoreNativeLyricsContent(host) {
    if (!host) return;
    reconcileStale();
    Array.from(host.children).forEach((child) => {
      if (child.id === PANEL_ID) return;
      child.style.display = staleNative.has(child) ? 'none' : '';
    });
    nudgeRelayout();
  }

  
  function nudgeRelayout() {
    requestAnimationFrame(() => {
      window.dispatchEvent(new Event('resize'));
      requestAnimationFrame(() => window.dispatchEvent(new Event('resize')));
    });
  }

  function teardownPanel() {
    const panel = document.getElementById(PANEL_ID);
    const host = findTabContentHost();
    if (panel) panel.remove();
    host?.classList.remove('vivi-lyrics-edge-fade', 'vivi-fade-top', 'vivi-fade-bottom');
    restoreNativeLyricsContent(host);
    removeInfoButton();
    offsetPanelOpen = false;
  }


  let dancerUrl = null;
  function getDancerUrl() {
    if (!dancerUrl) {
      try { dancerUrl = chrome.runtime.getURL('icons/lyrics-dancer.webm'); } catch { dancerUrl = null; }
    }
    return dancerUrl;
  }

  function renderDancerState(panel, caption, sub) {
    panel.innerHTML = '';
    const wrap = document.createElement('div');
    wrap.className = 'vivi-lyrics-video-blocked';

    const url = settings.resourceSaverEnabled ? null : getDancerUrl(); // no looping video in resource saving mode
    if (url) {
      const video = document.createElement('video');
      video.className = 'vivi-lyrics-dancer';
      video.src = url;
      video.autoplay = true;
      video.loop = true;
      video.muted = true;
      video.playsInline = true;
      video.disablePictureInPicture = true;
      wrap.appendChild(video);
    }

    const captionEl = document.createElement('div');
    captionEl.className = 'vivi-lyrics-video-blocked-caption';
    captionEl.textContent = caption;
    wrap.appendChild(captionEl);

    if (sub) {
      const subEl = document.createElement('div');
      subEl.className = 'vivi-lyrics-video-blocked-sub';
      subEl.textContent = sub;
      wrap.appendChild(subEl);
    }

    panel.appendChild(wrap);
    activeLineEl = null;
  }

  function renderVideoBlockedState(panel) {
    renderDancerState(
      panel,
      "Lyrics are off for video songs",
      'Turn this back on under Lyrics → "Show lyrics for video songs".'
    );
  }

  function renderNotFoundState(panel) {
    if (settings.dancerOnNotFound && !settings.resourceSaverEnabled) {
      renderDancerState(panel, "No lyrics found for this track.", null);
    } else {
      panel.innerHTML = `<div class="vivi-lyrics-empty">No lyrics found for this track.</div>`;
    }
  }

  function reevaluateForVideoSetting() {
    // Called right after the "Show lyrics for video songs" toggle flips,
    // so the currently open Lyrics tab reacts immediately instead of
    // waiting for the next track change.
    if (!currentTrack) return;
    if (!settings.lyricsShowForVideos && currentIsVideo) {
      isLoadingLyrics = false;
      currentResult = VIDEO_BLOCKED;
      contentDirty = true;
      syncPanelVisibility();
    } else if (settings.lyricsShowForVideos && currentResult && currentResult.videoBlocked) {
      // Setting was turned back on — go fetch lyrics for the track that's
      // still playing, same as a fresh track change would. handleTrack()
      // re-derives the same track key internally, so just force it to treat
      // this as a new lookup instead of a no-op.
      currentTrackKey = null;
      handleTrack(currentTrack);
    }
  }

  function renderLoadingOrResult() {
    const panel = ensurePanel();
    if (!panel) return;
    const host = findTabContentHost();
    if (host) hideNativeLyricsContent(host);
    if (isLoadingLyrics) {
      panel.innerHTML = `<div class="vivi-lyrics-loading">Loading lyrics…</div>`;
      updateEdgeFade(findTabContentHost());
      return;
    }
    renderPanel(currentResult);
  }

  function syncPanelVisibility() {
    const host = findTabContentHost();
    if (!host) return;
    const shouldShow = settings.lyricsEnabled && !!currentTrackKey && isLyricsTabActive();

    if (shouldShow) {
      const existingPanel = document.getElementById(PANEL_ID);
      const panelInHost = existingPanel && existingPanel.parentElement === host;
      if (!panelInHost || contentDirty) {
       
        renderLoadingOrResult();
        contentDirty = false;
      } else {
        
        hideNativeLyricsContent(host);
      }
    } else if (document.getElementById(PANEL_ID)) {
      teardownPanel();
    } else if (isLyricsTabActive() && staleNative.size) {
      // Back on Lyrics with our panel off: native lyrics must be visible.
      clearStaleNative(host);
      Array.from(host.children).forEach((c) => { c.style.display = ''; });
    }

    ensureInfoButton();
    requestLyricsTick();
  }

  function scheduleSync() {
    
    if (syncRaf) cancelAnimationFrame(syncRaf);
    syncRaf = requestAnimationFrame(() => {
      syncRaf = null;
      syncPanelVisibility();
    });
  }

  // Inline offset editor, rendered at the top of the panel when the "i"
  // button is toggled on. ± buttons and the number input adjust the value
  // live for preview; nothing is written to chrome.storage until Save is
  // pressed.
  function buildOffsetPanel(result) {
    const wrap = document.createElement('div');
    wrap.id = OFFSET_PANEL_ID;
    wrap.className = 'vivi-offset-panel';

    const title = document.createElement('div');
    title.className = 'vivi-offset-panel-title';
    title.textContent = `Lyrics via ${result.provider}`;
    wrap.appendChild(title);

    const controls = document.createElement('div');
    controls.className = 'vivi-offset-panel-controls';

    const minus = document.createElement('button');
    minus.type = 'button';
    minus.className = 'vivi-offset-btn';
    minus.textContent = '−';
    minus.setAttribute('aria-label', 'Delay lyrics');
    minus.addEventListener('click', (e) => { e.stopPropagation(); adjustManualOffset(-OFFSET_STEP_MS); });

    const input = document.createElement('input');
    input.type = 'number';
    input.step = String(OFFSET_STEP_MS);
    input.className = 'vivi-offset-input';
    input.value = String(manualOffsetMs);
    input.setAttribute('aria-label', 'Lyrics offset in milliseconds');
    input.addEventListener('click', (e) => e.stopPropagation());
    input.addEventListener('keydown', (e) => {
      e.stopPropagation();
      if (e.key === 'Enter') input.blur();
    });
    input.addEventListener('change', () => {
      setManualOffsetLive(parseInt(input.value, 10) || 0);
    });

    const unit = document.createElement('span');
    unit.className = 'vivi-offset-unit';
    unit.textContent = 'ms';

    const plus = document.createElement('button');
    plus.type = 'button';
    plus.className = 'vivi-offset-btn';
    plus.textContent = '+';
    plus.setAttribute('aria-label', 'Advance lyrics');
    plus.addEventListener('click', (e) => { e.stopPropagation(); adjustManualOffset(OFFSET_STEP_MS); });

    const saveBtn = document.createElement('button');
    saveBtn.type = 'button';
    saveBtn.className = 'vivi-offset-save-btn';
    saveBtn.textContent = offsetIsDirty() ? 'Save' : 'Saved';
    saveBtn.disabled = !offsetIsDirty();
    saveBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      persistManualOffset();
    });

    const refetchBtn = document.createElement('button');
    refetchBtn.type = 'button';
    refetchBtn.className = 'vivi-offset-refetch-btn';
    refetchBtn.textContent = 'Refetch from other providers';
    refetchBtn.disabled = isRefetchingLyrics;
    refetchBtn.classList.toggle('vivi-offset-refetch-btn-loading', isRefetchingLyrics);
    refetchBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      refetchFromOtherProviders();
    });

    if (result.mode === 'plain') controls.append(refetchBtn);
    else controls.append(minus, input, unit, plus, saveBtn, refetchBtn);
    wrap.appendChild(controls);
    return wrap;
  }

  // "Refetch from other providers" — re-runs discovery while skipping the
  // provider currently on screen (and any providers the user has already
  // refetched away from for this exact song in the past). All the enabled
  // providers were already queried once when this track loaded, but the
  // losing results aren't kept around anywhere (no lyrics cache), so this
  // is a fresh, real fetch rather than a re-scan of old responses — same
  // network shape as the initial lookup, just with one or more providers
  // excluded. If something new turns up, it's shown immediately and that
  // provider's own saved offset (if any) is restored. The current provider
  // is only marked "don't show again for this song" once a replacement has
  // actually been found and displayed — if nothing else is out there, the
  // existing lyrics are left alone rather than being replaced with nothing.
  async function refetchFromOtherProviders() {
    if (isRefetchingLyrics || !currentTrack || !currentResult || currentResult.videoBlocked) return;
    const currentKey = window.__viviLyrics.providerKeyForName(currentResult.provider);
    if (!currentKey) return;

    isRefetchingLyrics = true;
    contentDirty = true;
    syncPanelVisibility();

    try {
      const alreadyExcluded = await loadExcludedProviders(currentTrack);
      const excludeKeys = [...new Set([...alreadyExcluded, currentKey])];
      const result = await window.__viviLyrics.fetchBestLyrics(currentTrack, { excludeKeys });

      if (!result) {
        // Nothing else out there — leave the current lyrics as-is and
        // don't persist the exclusion, so a future refetch (or a later
        // relisten once a provider catches up) can try again.
        return;
      }

      addExcludedProvider(currentTrack, currentKey);
      currentResult = result;
      contentDirty = true;
      manualOffsetMs = await loadOffset(currentTrack, result.provider);
      savedOffsetMs = manualOffsetMs;
      offsetPanelOpen = true;
      syncPanelVisibility();
    } finally {
      isRefetchingLyrics = false;
      contentDirty = true;
      syncPanelVisibility();
    }
  }

  // ── Fluid flow ───────────────────────────────────────────────────────────
  // Modelled on how the Better Lyrics engine (@braccato/core, MIT) moves:
  //  • Scrolling: the scroller jumps instantly, then every nearby line glides
  //    from its old position to its new one. All lines start together; lines
  //    further along the direction of travel get a slightly LONGER duration, so
  //    they trail rather than start late. Easing is a strong ease-in-out
  //    (slow start, quick middle, soft landing). The active line is parked at
  //    ~37% of the panel height, and the scroll starts ~0.54s before the line
  //    is sung, so motion is already under way when the words begin.
  //  • Words: split into letters. A soft colour front sweeps through them; each
  //    letter floats up as the front lights it, crests, and settles slightly
  //    raised. Long words also swell a little. The word gets a faint horizontal
  //    wobble and a glow that fades out.
  const isFluidStyle = () => settings.lyricsAnimationStyle === 'fluid';
  const isGlowStyle = () => settings.lyricsAnimationStyle === 'glow';

  const FLUID_SCROLL_LEAD_MS = 540;
  const FLUID_SCROLL_RATIO = 0.37;
  const FLUID_SCROLL_BASE_MS = 750;
  const FLUID_SCROLL_EASING = 'cubic-bezier(0.86, 0, 0.2, 1)';
  const FLUID_WAVE_MS = 900;
  const FLUID_WAVE_CREST = 0.4;
  const FLUID_LONG_WORD_MS = 1500;
  let fluidScrollEl = null; // the line the last fluid scroll was aimed at

  function findScrollParent(el) {
    for (let p = el && el.parentElement; p && p !== document.body; p = p.parentElement) {
      const oy = getComputedStyle(p).overflowY;
      if ((oy === 'auto' || oy === 'scroll') && p.scrollHeight > p.clientHeight + 1) return p;
    }
    return findTabContentHost();
  }

  const currentTranslateY = (el) => {
    const t = getComputedStyle(el).translate; // "none" | "0px 12.5px"
    if (!t || t === 'none') return 0;
    return parseFloat(t.split(' ')[1]) || 0;
  };

  function scrollToActive(active) {
    if (!active) return;
    const reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (!isFluidStyle() || reduce || typeof active.animate !== 'function') {
      active.scrollIntoView({ block: 'center', behavior: 'smooth' });
      return;
    }
    const host = findScrollParent(active);
    if (!host) { active.scrollIntoView({ block: 'center', behavior: 'smooth' }); return; }

    // Park the line's centre at ~37% of the panel. Any in-flight glide is
    // subtracted so a mid-animation line is measured at its layout position.
    const hostRect = host.getBoundingClientRect();
    const aRect = active.getBoundingClientRect();
    const aCenter = aRect.top - currentTranslateY(active) + aRect.height / 2;
    const want = host.scrollTop + (aCenter - (hostRect.top + hostRect.height * FLUID_SCROLL_RATIO));
    const target = Math.max(0, Math.min(want, host.scrollHeight - host.clientHeight));
    const d = target - host.scrollTop;
    if (Math.abs(d) < 1) return;

    const lines = Array.from(active.parentElement.querySelectorAll('.vivi-lyrics-line'));
    const ai = lines.indexOf(active);
    const WINDOW = 14;
    const near = [];
    lines.forEach((el, i) => { if (Math.abs(i - ai) <= WINDOW) near.push({ el, i }); });

    // Gap between the active line and its closest neighbour: when the scroll is
    // longer than that, trailing lines are held closer to the active line's
    // duration so the lines don't visibly pile into each other.
    const centerOf = (el) => { const r = el.getBoundingClientRect(); return r.top - currentTranslateY(el) + r.height / 2; };
    const gaps = [lines[ai - 1], lines[ai + 1]].filter(Boolean).map((el) => Math.abs(centerOf(el) - aCenter));
    const stepPx = gaps.length ? Math.min(...gaps) : aRect.height;
    const stagger = Math.min(1, stepPx / Math.abs(d));

    const prev = host.style.scrollBehavior;
    host.style.scrollBehavior = 'auto';
    host.scrollTop = target;
    host.style.scrollBehavior = prev;

    // A seek across most of the song: don't fly every line across the screen.
    if (Math.abs(d) > host.clientHeight * 1.2) return;

    const forward = d > 0;
    near.forEach(({ el, i }) => {
      const rel = i - ai;
      const abs = Math.abs(rel);
      const ahead = forward ? rel > 0 : rel < 0; // lines in the direction of travel
      let dur = FLUID_SCROLL_BASE_MS;
      if (rel !== 0) {
        const raw = ahead
          ? FLUID_SCROLL_BASE_MS + Math.log(abs + 2) * 80 + (abs + 1) * 20
          : FLUID_SCROLL_BASE_MS + Math.min(abs, 6) * 20;
        dur = FLUID_SCROLL_BASE_MS + (raw - FLUID_SCROLL_BASE_MS) * stagger;
      }
      // composite:'add' stacks on any glide still running, so rapid line
      // changes blend instead of restarting.
      el.animate(
        [{ translate: '0 ' + d + 'px' }, { translate: '0 0' }],
        { duration: dur, easing: FLUID_SCROLL_EASING, composite: 'add', fill: 'none' }
      );
    });
  }

  // ── Fluid flow: per-letter word animation ──
  const flowAnims = new Set();
  const segmentGraphemes = (() => {
    try {
      const seg = new Intl.Segmenter(undefined, { granularity: 'grapheme' });
      return (t) => Array.from(seg.segment(t), (x) => x.segment);
    } catch { return (t) => Array.from(t); }
  })();
  // Scripts where splitting into letters is safe. Joined scripts (Arabic, Indic,
  // Thai …) would lose their shaping, so those words keep the plain sweep.
  const FLOW_SAFE = /^[\p{Script=Latin}\p{Script=Cyrillic}\p{Script=Greek}\p{Script=Hangul}\p{Script=Hiragana}\p{Script=Katakana}\p{Script=Han}\p{N}\p{P}\p{S}\p{Zs}\p{M}]+$/u;

  function canFlow(w) {
    if (w.querySelector('.vivi-fl-ch')) return true;
    if (w.childElementCount) return false;
    const t = w.textContent || '';
    return t.trim().length > 0 && t.length <= 32 && FLOW_SAFE.test(t);
  }

  function splitIntoLetters(w) {
    const existing = w.querySelectorAll('.vivi-fl-ch');
    if (existing.length) return Array.from(existing);
    const frag = document.createDocumentFragment();
    const out = [];
    segmentGraphemes(w.textContent || '').forEach((c) => {
      const s = document.createElement('span');
      s.className = 'vivi-fl-ch';
      s.textContent = c;
      frag.appendChild(s);
      out.push(s);
    });
    w.textContent = '';
    w.appendChild(frag);
    w.classList.add('vivi-fl-split');
    return out;
  }

  function cancelFlow(root) {
    root.getAnimations({ subtree: true }).forEach((a) => { if (a.__viviFl) a.cancel(); });
    root.querySelectorAll('.vivi-fl-lit').forEach((el) => el.classList.remove('vivi-fl-lit'));
  }

  function unsplitLetters(root) {
    (root || document).querySelectorAll('.vivi-fl-split').forEach((w) => {
      cancelFlow(w);
      w.textContent = w.textContent;
      w.classList.remove('vivi-fl-split');
    });
  }

  function bindFlowVideo() {
    const v = getVideoEl();
    if (!v || v.__viviFlBound) return;
    v.__viviFlBound = true;
    // Web animations run on their own clock, so keep them in step with the song.
    v.addEventListener('pause', () => flowAnims.forEach((a) => a.pause()));
    v.addEventListener('play', () => flowAnims.forEach((a) => a.play()));
    v.addEventListener('ratechange', () => flowAnims.forEach((a) => { a.playbackRate = v.playbackRate || 1; }));
  }

  function startFlowAnim(el, keyframes, options, elapsedMs, onDone) {
    const a = el.animate(keyframes, options);
    a.__viviFl = true;
    a.currentTime = elapsedMs;
    const v = getVideoEl();
    a.playbackRate = (v && v.playbackRate) || 1;
    flowAnims.add(a);
    const done = (cancel) => { flowAnims.delete(a); if (onDone) onDone(); if (cancel) { try { a.cancel(); } catch { /* gone */ } } };
    a.addEventListener('finish', () => done(true), { once: true });
    a.addEventListener('cancel', () => flowAnims.delete(a), { once: true });
    return a;
  }

  function flowWord(w, state, prevState, elapsedMs, durMs) {
    if (state === 'upcoming') { cancelFlow(w); return; }
    if (state === 'sung') {
      // Normal hand-over from 'active': let the tail of the wave finish.
      // Anything else (a seek landed past it): drop to the resting state.
      if (prevState !== 'active') cancelFlow(w);
      return;
    }
    bindFlowVideo();
    cancelFlow(w);
    const letters = splitIntoLetters(w);
    const n = letters.length;
    if (!n) return;
    const D = Math.max(160, durMs);
    const lead = D * 0.1;                       // the front starts a touch early
    const per = D / n;                          // time the front spends per letter
    const fillMs = Math.max(per * 2, 140);      // soft edge spans about two letters
    const riseMs = FLUID_WAVE_MS * FLUID_WAVE_CREST;
    const long = D > FLUID_LONG_WORD_MS;
    const rest = long ? ' scale(1)' : '';
    const peak = 'translateY(-0.05em)' + (long ? ' scale(1.11)' : '');

    letters.forEach((el, i) => {
      const touched = i * per - lead;           // front reaches this letter
      const lit = touched + fillMs;             // letter fully coloured
      startFlowAnim(el,
        [{ backgroundPosition: '100% 0' }, { backgroundPosition: '0% 0' }],
        { duration: fillMs, delay: touched, easing: 'linear', fill: 'both' },
        elapsedMs, () => el.classList.add('vivi-fl-lit'));
      // Each letter crests just as the front finishes colouring it.
      let wDelay; let wDur;
      if (lit - riseMs > touched) { wDelay = touched; wDur = (lit - touched) / FLUID_WAVE_CREST; }
      else { wDelay = lit - riseMs; wDur = FLUID_WAVE_MS; }
      startFlowAnim(el, [
        { transform: 'translateY(0)' + rest, easing: 'ease-in-out' },
        { transform: peak, offset: FLUID_WAVE_CREST, easing: 'ease-out' },
        { transform: 'translateY(-0.02em)' + rest },
      ], { duration: wDur, delay: wDelay, fill: 'forwards' }, elapsedMs);
    });

    // Whole word: a faint sideways wobble and a glow that fades away.
    startFlowAnim(w, [
      { transform: 'scaleX(1)' },
      { transform: 'translateX(0.05em) scaleX(1.025)', offset: 0.125, easing: 'ease-in-out' },
      { transform: 'translateX(0) scaleX(1)', offset: 0.75 },
      { transform: 'scaleX(1)', easing: 'ease-out' },
    ], { duration: 1000, easing: 'ease', fill: 'forwards' }, elapsedMs);
    startFlowAnim(w, [
      { filter: 'drop-shadow(0 0 0.8rem rgba(255,255,255,0.55))' },
      { filter: 'drop-shadow(0 0 0 rgba(255,255,255,0))' },
    ], { duration: Math.max(D * 1.2, 1200), easing: 'ease', fill: 'none' }, elapsedMs);
  }

  // Apple Music style blurs lines progressively the further they are from the
  // active line. Store each line's distance as a CSS variable.
  function updateLineDistances(listEl) {
    const list = listEl || document.querySelector('.vivi-lyrics-list');
    if (!list || !list.classList.contains('vivi-lyrics-anim-apple')) return;
    const lines = list.querySelectorAll('.vivi-lyrics-line');
    let activeIdx = -1;
    lines.forEach((el, i) => { if (el.classList.contains('vivi-lyrics-active')) activeIdx = i; });
    // Between lines (instrumental gaps / tiny gaps between timestamps) no line
    // is active. Falling back to "everything is distance 1" made the line that
    // had just been sung snap from sharp to blurred, then back to sharp when the
    // next line began -- a visible blur flicker. Keep measuring from the last
    // active line instead so the blur layout stays constant.
    if (activeIdx < 0 && anchorLineEl && anchorLineEl.isConnected) {
      const i = Array.prototype.indexOf.call(lines, anchorLineEl);
      if (i >= 0) activeIdx = i;
    }
    lines.forEach((el, i) => {
      el.style.setProperty('--vivi-d', activeIdx < 0 ? 1 : Math.min(Math.abs(i - activeIdx), 5));
    });
  }

  // Re-applies the alignment/animation-style classes to an already-rendered
  // list without rebuilding it, so flipping a setting mid-song updates the
  // panel immediately.
  function applyLyricsStyleClasses(listEl) {
    const list = listEl || document.querySelector('.vivi-lyrics-list');
    if (!list) return;
    // Smooth zoom and Apple Music are left-aligned by design, whatever the
    // alignment setting says.
    const forceLeft = settings.lyricsAnimationStyle === 'zoom' || settings.lyricsAnimationStyle === 'apple';
    list.classList.remove('vivi-lyrics-align-left', 'vivi-lyrics-align-center', 'vivi-lyrics-align-right');
    list.classList.add('vivi-lyrics-align-' + (forceLeft ? 'left' : (settings.lyricsAlign || 'center')));
    list.classList.toggle('vivi-lyrics-anim-glow', isGlowStyle());
    list.classList.toggle('vivi-lyrics-anim-fluid', isFluidStyle());
    list.classList.toggle('vivi-lyrics-anim-bounce', settings.lyricsAnimationStyle === 'bounce');
    list.classList.toggle('vivi-lyrics-anim-zoom', settings.lyricsAnimationStyle === 'zoom');
    list.classList.toggle('vivi-lyrics-anim-apple', settings.lyricsAnimationStyle === 'apple');
    if (!isFluidStyle()) { unsplitLetters(list); fluidScrollEl = null; }
    updateLineDistances(list);
    // Lyrics-only font: swap just the vivi-lyrics-font-* class on the list.
    [...list.classList].filter((c) => c.startsWith('vivi-lyrics-font-')).forEach((c) => list.classList.remove(c));
    if (settings.lyricsFont && settings.lyricsFont !== 'default') {
      list.classList.add('vivi-lyrics-font-' + String(settings.lyricsFont).replace(/[^a-z0-9]/gi, ''));
      ensureLyricsFontLoaded(settings.lyricsFont);
    }
  }

  // ── Romanization ─────────────────────────────────────────────────────────
  // settings.lyricsRoman: 'off' | 'only' (romanized replaces the original)
  //                       | 'both' (romanized line under each original line)
  // The offline work lives in romanize.js; Japanese lines that contain kanji
  // are resolved asynchronously and patched into the DOM line by line.
  const romanCache = new WeakMap();

  function flatRomanUnits(line, result) {
    const units = [];
    line.words.forEach((w, wi) => {
      const gap = wi > 0 && !line.words[wi - 1].joined;
      const parts = result.mode === 'syllable' && w.syllables && w.syllables.length ? w.syllables : [w];
      parts.forEach((p, si) => units.push({ text: p.text, sep: si === 0 && gap ? ' ' : '' }));
    });
    return units;
  }

  // Online (whole-line) romaji -> per-unit text, so the word / syllable
  // animation stays identical to the original lyrics.
  function applyOnlineUnits(rl, line, result) {
    const R = window.__viviRoman;
    if (!R || !R.splitRomanByUnits || !rl.online) return;
    if (!((result.mode === 'word' || result.mode === 'syllable') && Array.isArray(line.words) && line.words.length)) return;
    const units = [];
    const lastOfWord = [];
    line.words.forEach((w) => {
      const parts = result.mode === 'syllable' && w.syllables && w.syllables.length ? w.syllables : [w];
      parts.forEach((p, si) => {
        const last = si === parts.length - 1;
        units.push({ text: p.text, snap: last && !w.joined });
        lastOfWord.push(last);
      });
    });
    const chunks = R.splitRomanByUnits(rl.online, units);
    if (!chunks || chunks.length !== units.length) return;
    rl.units = chunks.map((c, k) => (lastOfWord[k] || !c.spaceAfter ? c.text : c.text + ' '));
    const wordJoined = [];
    let k = 0;
    line.words.forEach((w) => {
      const parts = result.mode === 'syllable' && w.syllables && w.syllables.length ? w.syllables : [w];
      k += parts.length;
      wordJoined.push(!!w.joined && !chunks[k - 1].spaceAfter);
    });
    rl.wordJoined = wordJoined;
  }

  function getRomanView(result) {
    const mode = settings.lyricsRoman;
    const R = window.__viviRoman;
    if (!mode || mode === 'off' || !R || !result || !Array.isArray(result.lines)) return null;
    // Online lookup for kanji is automatic: it only runs for lines that get
    // romanized, i.e. when Japanese is ticked under "Languages to romanize".
    const jaOnline = true;
    let langs = Array.isArray(settings.lyricsRomanLangs) ? settings.lyricsRomanLangs : null;
    // Older versions saved "all languages" as the six original ids; treat that
    // as "all" so the newer languages are included too.
    if (langs && langs.length === 6 && ['ko', 'ja', 'zh', 'hi', 'pa', 'ka'].every((x) => langs.includes(x))) langs = null;
    const sig = jaOnline + '|' + (langs ? langs.join(',') : '*');
    const hit = romanCache.get(result);
    if (hit && hit.sig === sig) return hit.rv;
    const ctx = R.analyzeSong(result.lines);
    if (langs) ctx.langs = new Set(langs);
    let any = false;
    const lines = result.lines.map((line) => {
      const base = R.romanizeLine(line.text || '', ctx);
      if (!base) {
        // Scripts without an offline converter (Bengali, Tamil, Arabic, Cyrillic…):
        // the Latin spelling is looked up online, line by line.
        if (!R.onlineLangOf || !R.onlineLangOf(line.text || '', ctx)) return null;
        any = true;
        const orl = { src: line.text, text: '', units: null, wordJoined: null, online: null, pending: false };
        const hit = R.getCachedJapanese(line.text);
        if (hit) { orl.online = hit; applyOnlineUnits(orl, line, result); } else orl.pending = true;
        return orl;
      }
      any = true;
      const rl = { src: line.text, text: base.text, units: null, wordJoined: null, online: null, pending: false };
      if (base.unresolvedHan) {
        const cached = jaOnline ? R.getCachedJapanese(line.text) : null;
        if (cached) { rl.online = cached; applyOnlineUnits(rl, line, result); }
        else if (jaOnline) rl.pending = true;
        return rl;
      }
      if ((result.mode === 'word' || result.mode === 'syllable') && Array.isArray(line.words) && line.words.length) {
        const ru = R.romanizeUnits(flatRomanUnits(line, result), ctx);
        if (ru.any && ru.units) {
          rl.units = ru.units;
          const chars = line.words.reduce((n, w) => n + w.text.length, 0);
          const noSpaces = line.words.every((w, k) => w.joined || k === line.words.length - 1);
          const spaced = ru.spaced || (noSpaces && chars / line.words.length >= 1.8);
          rl.wordJoined = line.words.map((w) => (spaced ? false : !!w.joined));
        }
      }
      return rl;
    });
    const rv = any ? { lines } : null;
    romanCache.set(result, { sig, rv });
    return rv;
  }

  function populateLine(lineEl, line, i, result, rv) {
    const rl = rv && rv.lines[i];
    const mode = settings.lyricsRoman;
    const romanText = rl && !rl.pending ? (rl.online || rl.text) : null;
    const romanOnly = mode === 'only' && !!romanText;
    const hasWords = (result.mode === 'word' || result.mode === 'syllable') && Array.isArray(line.words) && line.words.length;

    const makeUnit = (u, extra, text) => {
      const span = document.createElement('span');
      span.className = 'vivi-lyrics-word' + (extra ? ' ' + extra : '');
      span.dataset.start = String(u.start);
      span.dataset.end = String(u.end);
      span.textContent = text != null ? text : u.text;
      span.addEventListener('click', (e) => {
        e.stopPropagation();
        seekTo(u.start);
      });
      return span;
    };

    if (hasWords && romanOnly && !rl.units) {
      // Line-level romanization (no per-word mapping available): one unit
      // that spans the whole line.
      lineEl.appendChild(makeUnit({ start: line.start, end: line.end }, '', romanText));
    } else if (hasWords) {
      const useRoman = romanOnly && !!rl.units;
      let ui = 0;
      line.words.forEach((w, wi) => {
        const joined = useRoman && rl.wordJoined ? rl.wordJoined[wi] : w.joined;
        if (result.mode === 'syllable') {
          // Each word is a group; each syllable inside it is the unit
          // that actually animates (see tick()).
          const group = document.createElement('span');
          group.className = 'vivi-lyrics-wordgroup'
            + (joined ? ' vivi-lyrics-wordgroup-joined' : '')
            + (w.bg ? ' vivi-lyrics-wordgroup-bg' : '');
          group.dataset.start = String(w.start);
          group.dataset.end = String(w.end);
          (w.syllables && w.syllables.length ? w.syllables : [w]).forEach((sy) => {
            group.appendChild(makeUnit(sy, 'vivi-lyrics-syl', useRoman ? rl.units[ui] : null));
            ui++;
          });
          lineEl.appendChild(group);
        } else {
          lineEl.appendChild(makeUnit(w, (joined ? 'vivi-lyrics-word-joined ' : '') + (w.bg ? 'vivi-lyrics-word-bg' : ''), useRoman ? rl.units[ui] : null));
          ui++;
        }
      });
    } else {
      lineEl.textContent = romanOnly ? romanText : line.text;
    }

    if (mode === 'both' && romanText) {
      const sub = document.createElement('span');
      sub.className = 'vivi-lyrics-roman';
      sub.textContent = romanText;
      lineEl.appendChild(sub);
    }
  }

  function startOnlineRoman(result, rv) {
    if (!rv || !window.__viviRoman) return;
    rv.lines.forEach((rl, i) => {
      if (!rl || !rl.pending || rl.requested) return;
      rl.requested = true;
      window.__viviRoman.romanizeJapaneseOnline(rl.src).then((res) => {
        rl.pending = false;
        if (res) { rl.online = res; applyOnlineUnits(rl, result.lines[i], result); }
        if (currentResult !== result) return;
        const el = document.querySelector('.vivi-lyrics-list .vivi-lyrics-line[data-index="' + i + '"]');
        if (!el) return;
        el.textContent = '';
        populateLine(el, result.lines[i], i, result, rv);
      });
    });
  }

  function renderPanel(result) {
    const panel = ensurePanel();
    if (!panel) return;
    const host = findTabContentHost();
    if (host) hideNativeLyricsContent(host);

    if (result && result.videoBlocked) {
      renderVideoBlockedState(panel);
      updateEdgeFade(findTabContentHost());
      return;
    }

    if (!result) {
      renderNotFoundState(panel);
      updateEdgeFade(findTabContentHost());
      return;
    }

    const frag = document.createDocumentFragment();

    if (offsetPanelOpen && result.provider) {
      frag.appendChild(buildOffsetPanel(result));
    }

    const list = document.createElement('div');
    list.className = 'vivi-lyrics-list';
    applyLyricsStyleClasses(list);

    const romanView = getRomanView(result);
    result.lines.forEach((line, i) => {
      const lineEl = document.createElement('div');
      lineEl.className = 'vivi-lyrics-line';
      lineEl.dataset.index = String(i);

      populateLine(lineEl, line, i, result, romanView);
      if (result.mode !== 'plain') {
        lineEl.dataset.start = String(line.start);
        lineEl.dataset.end = String(line.end);
        lineEl.classList.add('vivi-lyrics-clickable');
        lineEl.addEventListener('click', () => seekTo(line.start));
      }
      list.appendChild(lineEl);
    });
    startOnlineRoman(result, romanView);

    frag.appendChild(list);

    if (result.provider) {
      const creditRow = document.createElement('div');
      creditRow.className = 'vivi-lyrics-credit-row';

      const credit = document.createElement('span');
      credit.className = 'vivi-lyrics-credit';
      const levelLabel = { syllable: 'syllable-synced', word: 'word-synced', line: 'line-synced' }[result.mode];
      credit.textContent = `Lyrics via ${result.provider}` + (levelLabel ? ` · ${levelLabel}` : '');
      creditRow.appendChild(credit);

      frag.appendChild(creditRow);
    }

    panel.innerHTML = '';
    panel.appendChild(frag);
    activeLineEl = null;
    anchorLineEl = null;
    fluidScrollEl = null;

    // New song -> start at the top. The scroll container keeps the previous
    // song's scroll offset (we were parked at the last line + credit row), so
    // without this the next song's lyrics appeared scrolled to the bottom until
    // the first line was sung and scrollIntoView() pulled them into place.
    // Keyed on the lyrics identity so a mere re-render (font/animation change,
    // offset panel toggle) mid-song doesn't jump back to the top.
    const renderKey = [result.provider || '', result.mode || '', result.lines.length,
      result.lines[0]?.text ?? '', result.lines[result.lines.length - 1]?.text ?? ''].join('|');
    if (renderKey !== lastRenderedKey) {
      lastRenderedKey = renderKey;
      const h = findTabContentHost();
      [h, panel, panel.parentElement].forEach((el) => {
        if (!el) return;
        const prev = el.style.scrollBehavior;
        el.style.scrollBehavior = 'auto'; // instant, not an animated scroll up the whole song
        el.scrollTop = 0;
        el.style.scrollBehavior = prev;
      });
    }
    updateEdgeFade(findTabContentHost());
  }

  let cachedVideo = null;

  function getVideoEl() {
    if (cachedVideo && cachedVideo.isConnected && cachedVideo.classList.contains('html5-main-video')) {
      return cachedVideo;
    }

    const main = document.querySelector('#movie_player video.html5-main-video, video.html5-main-video');
    if (main) { cachedVideo = main; return main; }
    const scoped = document.querySelector('#movie_player video');
    if (scoped) { cachedVideo = scoped; return scoped; }

    cachedVideo = null;
    return null;
  }

  function shouldRunLyricsTick() {
    if (!settings.lyricsEnabled || !currentResult || currentResult.videoBlocked || currentResult.mode === 'plain') return false;
    if (document.visibilityState === 'hidden' || !isLyricsTabActive() || !document.getElementById(PANEL_ID)) return false;
    const video = getVideoEl();
    return !!video && !video.paused && !video.ended;
  }

  function requestLyricsTick() {
    if (rafId === null && shouldRunLyricsTick()) rafId = requestAnimationFrame(tick);
  }

  function tick() {
    rafId = null;
    if (!shouldRunLyricsTick()) return;
    const video = getVideoEl();
    if (!video) return;
    // Shift the raw video position back by whatever SponsorBlock already
    // skipped past (so lyrics stay aligned to the real song, not the video
    // file's timeline), then apply the user's manual fine-tune correction.
    const nowMs = (video.currentTime * 1000) - sponsorOffsetMs + manualOffsetMs;

    const panel = document.getElementById(PANEL_ID);
    if (!panel) return;
    const lineEls = panel.querySelectorAll('.vivi-lyrics-line');
    let active = null;
    for (const el of lineEls) {
      const start = Number(el.dataset.start);
      const end = Number(el.dataset.end);
      if (nowMs >= start && nowMs < end) { active = el; break; }
    }

    if (active !== activeLineEl) {
      activeLineEl?.classList.remove('vivi-lyrics-active');
      // Settle every word in the outgoing line to its final "sung" resting
      // state and strip any in-progress animation class/inline style. Left
      // untouched, a word whose line changed mid-glow (or mid-bounce, or
      // mid-fill) would keep its transient class forever — that's the stuck
      // glow on the last word of a finished line.
      activeLineEl?.querySelectorAll('.vivi-lyrics-word').forEach((w) => {
        w.dataset.fillState = 'sung';
        w.classList.add('vivi-lyrics-word-sung');
        w.classList.remove('vivi-lyrics-word-glowing', 'vivi-lyrics-word-bouncing', 'vivi-lyrics-syl-swell');
        w.style.transitionDuration = '0s';
        w.style.backgroundPosition = '0% 0';
      });
      activeLineEl?.querySelectorAll('.vivi-lyrics-wordgroup').forEach((g) => {
        g.dataset.gState = 'sung';
        g.classList.remove('vivi-lyrics-wordgroup-active');
        g.classList.add('vivi-lyrics-wordgroup-sung');
      });
      active?.classList.add('vivi-lyrics-active');
      activeLineEl = active;
      if (active) anchorLineEl = active;
      updateLineDistances();
      if (!isFluidStyle()) scrollToActive(active);
    }

    // Fluid flow scrolls ahead of the line being sung, so the glide is already
    // under way when its first word lights up.
    if (isFluidStyle()) {
      const ahead = nowMs + FLUID_SCROLL_LEAD_MS;
      let target = null;
      for (const el of lineEls) {
        if (ahead >= Number(el.dataset.start) && ahead < Number(el.dataset.end)) { target = el; break; }
      }
      if (target && target !== fluidScrollEl) { fluidScrollEl = target; scrollToActive(target); }
    }

    if ((currentResult.mode === 'word' || currentResult.mode === 'syllable') && active) {
      const words = active.querySelectorAll('.vivi-lyrics-word');
      words.forEach((w) => {
        const ws = Number(w.dataset.start);
        const we = Number(w.dataset.end);

        let state;
        if (nowMs >= we) state = 'sung';
        else if (nowMs >= ws) state = 'active';
        else state = 'upcoming';

        // Only touch the DOM when a word's state actually changes, so the
        // fill transition isn't restarted every animation frame.
        if (w.dataset.fillState === state) return;
        const prevState = w.dataset.fillState;
        w.dataset.fillState = state;
        w.classList.toggle('vivi-lyrics-word-sung', state === 'sung');

        // Long-held syllables slowly swell while they're being sung.
        if (w.classList.contains('vivi-lyrics-syl')) {
          const held = we - ws;
          if (state === 'active' && held >= 900 && settings.lyricsAnimationStyle !== 'bounce' && !isFluidStyle()) {
            w.style.setProperty('--vivi-dur', held + 'ms');
            w.classList.remove('vivi-lyrics-syl-swell');
            void w.offsetWidth;
            w.classList.add('vivi-lyrics-syl-swell');
          } else {
            w.classList.remove('vivi-lyrics-syl-swell');
          }
        }

        if (isGlowStyle()) {
          // Glow-up: instead of a sweeping gradient fill, the word snaps to
          // "sung" color and gets a brief glow pulse exactly as it starts,
          // fading back out over the rest of its spoken duration.
          w.classList.toggle('vivi-lyrics-word-glowing', state === 'active');
          if (state === 'active') {
            w.style.transitionDuration = '0s';
            void w.offsetWidth;
            const dur = Math.max(150, we - ws);
            w.style.transitionDuration = dur + 'ms';
          } else {
            w.style.transitionDuration = '150ms';
          }
        } else if (settings.lyricsAnimationStyle === 'bounce') {
          // Word bounce: the whole active line is already lit up (see CSS),
          // and each word pops with a quick spring scale exactly as it's
          // sung, landing back at rest before the next word starts.
          if (state === 'active') {
            w.classList.remove('vivi-lyrics-word-bouncing');
            void w.offsetWidth;
            w.classList.add('vivi-lyrics-word-bouncing');
          } else {
            w.classList.remove('vivi-lyrics-word-bouncing');
          }
        } else if (isFluidStyle() && canFlow(w)) {
          flowWord(w, state, prevState, nowMs - ws, we - ws);
        } else if (state === 'sung') {
          // Snap straight to fully filled (covers seeks/skips landing past
          // the word's end without ever passing through 'active').
          w.style.transitionDuration = '0s';
          w.style.backgroundPosition = '0% 0';
        } else if (state === 'active') {
          // Reset to unfilled, force a reflow, then animate the fill sweep
          // across exactly this word's spoken duration so it lands right
          // as the word finishes — a smooth "karaoke" fill instead of a glow.
          w.style.transitionDuration = '0s';
          w.style.backgroundPosition = '100% 0';
          void w.offsetWidth;
          const dur = Math.max(0, we - ws);
          w.style.transitionDuration = dur + 'ms';
          w.style.transitionTimingFunction = 'linear';
          w.style.backgroundPosition = '0% 0';
        } else {
          w.style.transitionDuration = '0s';
          w.style.backgroundPosition = '100% 0';
        }
      });

      // Syllable mode: lift the word currently being sung (and settle it
      // once finished), the way Better Lyrics / Apple Music do.
      if (currentResult.mode === 'syllable') {
        active.querySelectorAll('.vivi-lyrics-wordgroup').forEach((g) => {
          const gs = Number(g.dataset.start);
          const ge = Number(g.dataset.end);
          const st = nowMs >= ge ? 'sung' : nowMs >= gs ? 'active' : 'upcoming';
          if (g.dataset.gState === st) return;
          g.dataset.gState = st;
          g.classList.toggle('vivi-lyrics-wordgroup-active', st === 'active');
          g.classList.toggle('vivi-lyrics-wordgroup-sung', st === 'sung');
        });
      }
    }
    // Keep per-frame timing only while word/syllable lyrics are visible and the
    // media is playing. Idle pages and paused audio do no animation work.
    requestLyricsTick();
  }

  function getCurrentVideoId() {
    const params = new URLSearchParams(window.location.search);
    const fromUrl = params.get('v');
    if (fromUrl) return fromUrl;
    const player = document.querySelector('#movie_player, ytmusic-player');
    try {
      const data = player?.getVideoData?.();
      if (data?.video_id) return data.video_id;
    } catch { /* ignore */ }
    return null;
  }

  async function handleTrack(track) {
    if (!settings.lyricsEnabled) return;
    if (!track) return;
    const key = `${track.artist}—${track.song}`;
    if (key === currentTrackKey) return;
    currentTrackKey = key;
    currentResult = null;
    isLoadingLyrics = true;
    contentDirty = true;
    sponsorOffsetMs = 0;
    manualOffsetMs = 0;
    savedOffsetMs = 0;
    offsetPanelOpen = false;

    enableLyricsTabIfDisabled();
    if (settings.autoSwitchLyrics) clickLyricsTabWithRetry();

    const durationEl = getVideoEl();
    const trackWithDuration = {
      ...track,
      duration: durationEl?.duration ? Math.round(durationEl.duration) : null,
      videoId: getCurrentVideoId(),
    };
    currentTrack = trackWithDuration;
    currentIsVideo = !!window.__viviTrackInfo?.isRealMusicVideo?.();

    // Real music videos can be opted out of lyrics entirely — skip the
    // network round-trip altogether and show the dancer placeholder.
    if (!settings.lyricsShowForVideos && currentIsVideo) {
      isLoadingLyrics = false;
      currentResult = VIDEO_BLOCKED;
      syncPanelVisibility();
      // No network fetch means no natural delay for the tab bar to finish
      // mounting/switching — nudge the sync again shortly after so the
      // panel still appears once clickLyricsTabWithRetry() actually lands.
      setTimeout(scheduleSync, 200);
      setTimeout(scheduleSync, 600);
      return;
    }

    syncPanelVisibility();

    await runLyricsFetch(trackWithDuration, key, { keepOffsetPanelOpen: false });
  }

  // Shared fetch-and-render path, called on every track change. There is
  // no lyrics cache — this always hits the lyrics providers fresh.
  async function runLyricsFetch(trackWithDuration, key, { keepOffsetPanelOpen }) {
    const excludeKeys = await loadExcludedProviders(trackWithDuration);
    if (key !== currentTrackKey) return; // track changed again while awaiting the exclusion lookup
    // Nothing is shown until the provider check settles: after the first
    // reply there is at most a 1s window in which the best sync level wins.
    const result = await window.__viviLyrics.fetchBestLyrics(trackWithDuration, { excludeKeys });
    if (key !== currentTrackKey) return; // track changed again while fetching

    // YT Music's video-vs-song signals (views/likes byline, native pixel
    // ratio) are frequently not settled yet at the moment the track first
    // changes — re-check now that time has passed so a video that only
    // "revealed itself" mid-fetch still gets the placeholder instead of
    // lyrics flashing briefly before being replaced.
    currentIsVideo = !!window.__viviTrackInfo?.isRealMusicVideo?.();
    if (!settings.lyricsShowForVideos && currentIsVideo) {
      isLoadingLyrics = false;
      currentResult = VIDEO_BLOCKED;
      contentDirty = true;
      syncPanelVisibility();
      return;
    }

    isLoadingLyrics = false;
    currentResult = result;
    contentDirty = true;
    offsetPanelOpen = keepOffsetPanelOpen && !!result;
    // Render immediately — don't gate the panel/offset button on the
    // chrome.storage round-trip below. fetchBestLyrics() can resolve
    // before YT Music has finished (re)mounting its own tab strip.
    // Previously we awaited loadOffset() first and only synced afterwards,
    // which just shifted the race later without fixing it — the offset
    // "i" button would silently stay missing until *something else*
    // happened to trigger the MutationObserver again (hence "works after
    // a refresh", where the extra page-load delay hides the race).
    syncPanelVisibility();
    // Belt-and-suspenders: nudge the sync a couple more times shortly
    // after, same as the video-blocked path below, in case the tab strip
    // was still mounting at the moment above and findTabByLabel('lyrics')
    // came back empty.
    setTimeout(scheduleSync, 200);
    setTimeout(scheduleSync, 600);

    // Restore any previously saved manual correction for this exact
    // song + artist + provider combination.
    manualOffsetMs = result ? await loadOffset(trackWithDuration, result.provider) : 0;
    savedOffsetMs = manualOffsetMs;
    if (key !== currentTrackKey) return; // track changed again while awaiting the offset lookup

    updateOffsetPanelValue();
  }

  function watchTabHost() {
    tabObserver?.disconnect();
    
    tabObserver = new MutationObserver(() => {
      enableLyricsTabIfDisabled();
      scheduleSync();
    });
    tabObserver.observe(document.documentElement, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ['aria-selected', 'selected', 'disabled', 'aria-disabled'],
    });
  }


  document.addEventListener('click', (e) => {
    const tab = e.target.closest('ytmusic-player-page tp-yt-paper-tab, ytmusic-player-page yt-tab-shape');
    if (!tab) return;

    enableLyricsTabIfDisabled();
    const host = findTabContentHost();
    if (host) {
      const label = window.__viviTabs
        ? (window.__viviTabs.kindOf(tab) || '')
        : (tab.textContent || '').trim().toLowerCase();
      // Capture phase: YTM hasn't switched yet, so this is the tab we're leaving.
      const leavingLyrics = isLyricsTabActive();
      if (leavingLyrics && (label === 'comments' || label === 'related')) {
        markStaleNative(host);
      } else if (label === 'lyrics' || label === 'up next' || label === 'next') {
        clearStaleNative(host);
      }
      reconcileStale();
      Array.from(host.children).forEach((child) => {
        if (child.id === PANEL_ID) return;
        child.style.display = staleNative.has(child) ? 'none' : '';
      });
    }
    scheduleSync();
    nudgeRelayout();
  }, true);

  watchTabHost();
  document.addEventListener('vivi-localization-changed', () => {
    enableLyricsTabIfDisabled();
    scheduleSync();
    if (currentTrack && settings.autoSwitchLyrics) clickLyricsTabWithRetry();
  });
  document.addEventListener('play', requestLyricsTick, true);
  document.addEventListener('playing', requestLyricsTick, true);
  document.addEventListener('timeupdate', requestLyricsTick, true);
  document.addEventListener('visibilitychange', requestLyricsTick);

  window.__viviLyricsUI = { handleTrack, setSponsorOffset };
})();
